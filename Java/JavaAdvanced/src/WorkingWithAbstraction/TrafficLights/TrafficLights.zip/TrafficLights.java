package WorkingWithAbstraction.TrafficLights;

public enum TrafficLights {
    RED,GREEN,YELLOW
}
